//evolution: 
//success : check => fetch => save
//fail : check => fetch fail => refetch => save
define('check', function(){

	var request = function(uri){

		if(!uri){ console.error("request，请输入正确的参数"); return; }

		var promise = new RSVP.Promise( function( resolve, reject ){

			var xhr = new XMLHttpRequest();
			xhr.open( 'GET', uri );

			xhr.onreadystatechange = function() {
				if ( xhr.readyState === 4 ) {
					if( xhr.status === 200 ) {
						resolve(xhr.responseText);
					} else {
						reject({
							errno : 0,
							err : "版本服务器/静态服务器错误!",
							xhr : xhr
						});
					}
				}
			};

			setTimeout( function () {
				if( xhr.readyState < 4 ) {
					xhr.abort();
				}
			}, 5000 );

			xhr.send();
		});

		return promise;

	};

	var filekey = sofa.config.FILELISTfile.replace(/\.js$/ig, "") || "FILELIST";

	var states = {
		"0" : "NOTMODIFIED",
		"1" : "UPDATE",
		"2" : "ADD",
		"3" : "DELETE"
	};

	var _diff = function( remote, local ){

		var result = [];
		var rkeys = Object.keys(remote);
		rkeys.forEach(function(key){

			if(key === "version"){ return; }

			// 0 or 1
			if(remote[key] && local[key]){

				if(remote[key].version === local[key].version){

					console.log(key, states[0]);
					result.push({
						key : key,
						action : 0
					});

				}

				if(remote[key].version > local[key].version){

					console.log(key, states[1]);
					result.push({
						key : key,
						action : 1
					});

				}

			}

			//2
			if(remote[key] && !local[key]){

				console.log(key, states[2]);
				result.push({
					key : key,
					action : 2
				});

			}
			
		});

		//3
		var lkeys = Object.keys(local);
		lkeys.forEach(function(key){

			if(local[key] && !remote[key]){

				result.push({
					key : key,
					action : 3
				});

			}

		});

		return result;

	};


	//将远程版本同本地版本对比，得到对比结果
	function check(info){

		var remote = info.remote,
			local = info.local;

		var promise = new RSVP.Promise(function(resolve, reject){

			//数据检查
			try{

				remote = JSON.parse(remote);

				if(typeof remote.version === undefined || typeof local.version === undefined) { 
				
					reject({
						errno : 0,
						err : "版本数据错误，请检查FILELIST和remoteFILELIST文件!"
					});

				};

				//没有版本更新时，删除多余版本
				if((remote.version - 0) <= (local.version - 0)){ 
					
					var x;
					for(x in remote){
						var info = remote[x];
						var res = sofa.get(x);
						if(res && info.version){
							try{
								var obj = JSON.parse(res);
								var l = Object.keys(obj);
								if(l.length > 1){
									var saveObj = {};
									saveObj["@"+info.version] = obj["@"+info.version];
									sofa.save(x, JSON.stringify(saveObj));
									console.log("removing previous version:", x);
								}	
							} catch (e){
								//文件完整性容错
								if(sofa.debug){ alert("FATAL FILE ERROR"); }
								sofa.storage.clear();
								sofa.reboot();
							}
						}
					}

					//这里其实是一个成功的promise，但是为了阻止程序的后续执行，就直接reject掉，在catch时处理。
					// reject({
					// 	errno : 1,
					// 	err : "已是最新版本，无需更新!"
					// });
				};

			} catch(e) {

				reject(e);

			}

			//分析版本信息
			resolve({
				diffInfo : _diff(remote, local),
				remote : remote,
				local : local
			});

		});
		
		return promise;

	};

	//抓取最新版本信息
	function fetch(data){

		var ret = [];
		var remote = data.remote;
		var diffInfo = data.diffInfo;

		//ADD UPDATE NOTMODIFED DELETE
		//@action fetch: 本地无存储 && state === ADD(2) || UPDATE(1) || NOTMODIFED(0)
		//@action delete: 本地有存储 && state === DELETE(3)
		var fetches = [], deletes = [];

		diffInfo.forEach(function(item){

			var key = item.key;
			var action = item.action;

			//storage已存储，文件已经删除，
			if(sofa.get(key) && action === 3){
				deletes.push(item);
			}

			//@原有策略:storage没有，也没有改变，需要fetch && save
			//@2015.3.5,现在的策略update: 全量下载升级成增量下载，如果本地版本和远程版本一样，不重复下载
			if(!sofa.get(key) && action === 0){
				//fetches.push(item);
			}

			//无论storage里有没有，都要fetch && save
			if(action === 1 || action === 2){
				fetches.push(item);
			}

		});

		//fetch
		var fetchPromises = fetches.map(function(item){

			var url;
			var type = ".js";
			//这里暂时只考虑了加载js的情况，需要改进
			if(remote[item.key].version){

				url = item.key + "-" + remote[item.key].version + type;

			} else{
				
				url = remote[item.key].url;

			}

			url = sofa.config.remoteServer + sofa.config.publicDir + url;

			return request(url);

		});
		
		//delete useless storage
		deletes.forEach(function(item){

			console.log(item.key, states[item.action]);
			sofa.remove(item.key);

		});

		return {
			fetches : fetches,
			action : RSVP.all(fetchPromises),
			remote : remote
		}

	};

	//存储最新版本信息和最新文件
	function save(info){

		var savelist = [];
		var fetches = info.fetches;
		var remoteFileInfo = info.remote;

		info.action.then(function(results){

			results.forEach(function(result, i){
				savelist.push({
					key : fetches[i].key,
					value : result
				});
			});

			//kv和localStorage接口都是同步方法，所以简化处理此处逻辑
			//可以和上一个forEach循环合并，为存储更清晰，分开写了
			savelist.forEach(function(toSave){
				
				var ver = remoteFileInfo[toSave.key].version;
				var old = sofa.get(toSave.key);
				var data = old ? JSON.parse(old) : {};
				data["@" + ver] = toSave.value;
				sofa.save(toSave.key, JSON.stringify(data));
				console.log("saving:", toSave.key, "@" + ver);

			});

			//存储最新版本信息
			var fileValue = 'define("' + filekey + '", ' + JSON.stringify(remoteFileInfo) + ')';
			sofa.save(filekey, fileValue);



			//整个过程完成，trigger完成事件。
			sofa.storage.trigger("evolutionComplete", savelist);

		});

	};

	function evolution(){

		if(sofa.debug) return ;

		//Evolution Frequency Control
		var lastCheckingTimestap = sofa.get(sofa.config.ETKey) - 0;
		if(!lastCheckingTimestap){
			sofa.save(sofa.config.ETKey, Date.now());
		} else {
			var interval = Date.now() - lastCheckingTimestap;
			if(interval < sofa.config.ETInterval){
				return console.log("更新频率控制!");
			} else {
				sofa.save(sofa.config.ETKey, Date.now());
				console.log("更新频率已升至最新!");
			}
		}

		var remoteAddr = sofa.config.remoteServer;
		var remoteInfo = request(remoteAddr);

		var localInfo = new RSVP.Promise(function(resolve, reject){

			require([filekey], function(ver){
				
				resolve(ver);

			});

		});

		RSVP.hash({
			remote : remoteInfo,
			local : localInfo
		})
		.then(check)
		.then(fetch)
		.then(save)
		.catch(function(e){

			if(typeof e.errno === undefined){
				//未知错误，不断补充
				console.trace(e);
			}

			if(e.errno === 1){
				//版本完全相同，什么都不做
			}

			if(e.errno === 0){
				//远程服务器错误，6s后重新尝试更新
				console.error(e.err);
				setTimeout( evolution , sofa.config.retryInterval);
			}

		});

	};

	evolution();

});