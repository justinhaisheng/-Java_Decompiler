//A simple storage wrapper
//@dependency: RSVP(https://github.com/tildeio/rsvp.js)

var storage = {

	getStorage: function() {

		return window.amapKvStorage;
	},

	setItem: function(k, v) {
		this.trigger('setStorage', {
			key: k,
			oldValue: this.getStorage().getItem(k),
			newValue: v
		});
		return this.getStorage().setItem(k, v);
	},

	getItem: function(k) {
		return this.getStorage().getItem(k);
	},

	removeItem: function(k) {
		this.trigger('removeStorage', {
			key: k,
			oldValue: this.getStorage().getItem(k),
			newValue: null
		});
		return this.getStorage().removeItem(k);
	},

	key: function(index) {
		return this.getStorage().key(index);
	},

	clear: function() {
		this.trigger('clearStorage', {
			oldValue: this.getStorage(),
			newValue: null
		});
		return this.getStorage().clear();
	}

};

RSVP.EventTarget.mixin(storage);