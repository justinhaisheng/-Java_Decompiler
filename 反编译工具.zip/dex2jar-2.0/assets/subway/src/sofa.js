   /*!
 * @overview sofa - Self-Evolution framework.
 * @copyright Copyright (c) 2014 huangxin
 * @license   Licensed under MIT license
 * @version   0.0.1
 * @dependencies 
 *		requirejs(https://github.com/jrburke/requirejs), 
 * 		RSVP(https://github.com/tildeio/rsvp.js)
 * 		storage.js
 */

var sofa = {};

!function(){

	"use strict";

	var original_loader = requirejs.load;

	var __applycss = function(v) {

		var head = document.head || document.getElementsByTagName('head')[0];
		var style = document.createElement("style");
		style.innerHTML = v;
		head.appendChild(style);

	};


	/**
     * Executes the text. Normally just uses eval, but can be modified
     * to use a better, environment-specific call. Only used for transpiling
     * loader plugins, not for plain JS modules.
     * @param {String} text the text to execute/evaluate.
     */
	var __applyjs = function(k, v){
		
		/**
			var head = document.head || document.getElementsByTagName('head')[0];
			var script = document.createElement("script");
			script.defer = true;
			script.text = v;
			head.appendChild( script );
			head.removeChild( script );
		 */
		try {
			eval(v);
		} catch(e){
			throw e;
		}		

	};
	
	
	var applyResource = function(key, res){

		try{
			//TODO: 处理更多的资源类型，如模板，JSON等。
			res = res.trim();
			var value;

			if(res.indexOf("define") === 0){
				
				value = res;
				__applyjs(key, value);

			} else {
				
				var obj = JSON.parse(res);
				value = obj["@" + sofa.fileInfo[key].version];
				
				if(sofa.fileInfo[key].type === "js"){
					__applyjs(key, value);
				} else {
					console.log("TODO: 处理更多的资源类型，如模板，JSON等。");
					//__applycss(res.data);
				}

			}	
		} catch(e) {

			//FATAL RUNTIME ERROR
			if(sofa.debug){ alert("FATAL RUNTIME ERROR"); }
			sofa.storage.clear();
			sofa.reboot();

		}
		

	};


	//Resource专指storage存储的的资源
	var saveResource = function(key, value){

		storage.setItem( sofa.config.prefix + key, value );

	};

	var removeResource = function(key){

		storage.removeItem( sofa.config.prefix + key );

	};

	var getResource = function(key){

		return storage.getItem(sofa.config.prefix + key);

	};

	var loadResource = function(key, callback, errCallback){

		var promise = new RSVP.Promise(function(resolve, reject){

			try {

				var res = storage.getItem( sofa.config.prefix + key);

				if(res){ applyResource(key, res); }

				original_loader([key], function(module){

					resolve(module);

				}, errCallback);			

			} catch(e){

				reject(e);

			}

		});

		return promise;

	};

	//override requirejs.load
	var hackRequire = function(){

		requirejs.load = function (context, moduleName, url) {
	        	
			try {

				var key = moduleName;

				var res = storage.getItem( sofa.config.prefix + key );

				if(res){ 

					applyResource(key, res);
					context.completeLoad(key);

				} else {

					original_loader(context, key, url);

				}

			} catch(e){

				context.onError(e);

			}

	    };

	}

	sofa.storage = storage;
	sofa.save = saveResource;
	sofa.get = getResource;
	sofa.remove = removeResource;
	sofa.pq = [];
	// sofa.apply = applyResource;

	//只支持命名模块
	
	/**
	sofa.define = function(name, deps, callback){

		if(typeof name !== 'string'){
			return console.error("sofa.define必须使用命名模块!");
		};

		//2个参数，没有deps的define call
		if(!callback){
			callback = deps;
			define(name, callback);
		}

		//特殊处理有deps的define call
		if(deps && Array.isArray(deps) && callback){
			deps.forEach(function(key){
				var v = sofa.get(key);
				//define storage deps
				if(v){
					applyResource(key, v);
				}
			});
			define(name, deps, callback);
		};

	}
	 */

	/**
	sofa.require = function(keys, callback, errCallback){

		if(Array.isArray(keys)){

			var promises = keys.map(function(key){

				return loadResource(key, callback, errCallback);

			});

			RSVP.all(promises).then(function(mods){

				if(callback) { callback.apply(null, mods); }

			}).catch(function(e){

				console.error(e);

			});

		} else if (typeof keys === "string"){

			return require(keys);

		} else {

			console.error("unexpected arguments calling sofa.require");

		}

	};
	 */
	
	sofa.reboot = function(){

		location.reload();
		
	};
	
	sofa.run = function(){

		var fileKey = sofa.config.FILELISTfile.replace(/\.js$/ig, "") || "FILELIST";

		require([fileKey], function(info){

			sofa.fileInfo = info;
			require(["boot"]);

		}, function(err){
			
			console.error(err);

		});
	};

	//这里需要优化初始化过程
	sofa.init = function(cb){
		
		var promise = new RSVP.Promise(function(resolve, reject){

			cb(resolve, reject);

		});

		sofa.pq.push(promise);

	}

	!function setup(){

		var configFile = "sofa.config.js";

		require([configFile], function(config){

			//ET = EvolutionTimestamp
			var midfix = "-sofa-";
			config.ETKey = "@EvolutionTimestap@";
			config.ETInterval = config.debugMode ? 3000 : 3000; //86400000;
			config.prefix = config.project + midfix;
			config.publicDir = config.publicDir || "public/";
			sofa.config = config;
			sofa.debug = !!config.debugMode;
			hackRequire();

			//KV/Storage ready，call 『sofa.init()』 manually;
			//sofa.init();
			RSVP.all(sofa.pq).then(function(data){
				sofa.run();
			}, function(err){
				console.log(arguments);
			});

		}, function(err){

			console.error(err);

		});

	}();

}();