define("app/js/subway/main", ['app/js/subway/common'], function(SW) {
    var tip = {
        isHighlight: false,
        isInfoShow: false,
        stationsInfo: SW.cache.stationsInfo,
        stations: SW.cache.stations,
        lines: SW.cache.lines,
        station_w: 26,
        dragObjXY: {}, //拖拽div时的实时xy
        dragX: null,
        dragY: null,
        onePoint: {}, //单手touch时的初始xy
        twoPoint1: {}, //双手touch时的初始x1y1
        twoPoint2: {}, //双手touch时的初始x2y2
        twoOriginPointDis: null, //双手touch时的两手指的初始距离
        touchStatus: null, //当前touch状态：drag, scale
        curScale: 1, //当前缩放级别
        allScale: 1,
        zoomCenter: null, //搜索初始中心点
        dragHandle: $("#drag_handle"), //touch对象
        dragObj: $("#subwaySvg"), //
        subwaySvg: document.getElementById("subway-svg"),
        dragObjOffset: {
            x: null,
            y: null
        },
        opentip: false,
        curopenStation: null,
        routeInfo: { //路线规划起始点信息
            start: null,
            end: null
        },
        routeId: {
            start: null,
            end: null
        },
        navDrwData: {
            linesbar: [],
            lines: {},
            stations: []
        },
        transform: {
            translate: {
                x: 0,
                y: 0
            },
            scale: 1
        },
        transformOrigin: null,
        routeState: false,
        fromendState: false,
        pathData: null,
        init: function() {
            this.bindEvent();
        },
        preventScrollBounce: function(eles) {
          if (!eles.length && !eles.unshift) {
            eles = [eles]
          }

          eles.forEach(function(el) {
            new Hammer.Manager(el, {
              recognizers: [
                [Hammer.Pinch, {direction: Hammer.DIRECTION_VERTICAL}],
                [Hammer.Swipe, {direction: Hammer.DIRECTION_VERTICAL}]
              ]
            })
          })

        },
        bindEvent: function() {
            var self = this;
            var font_size = 12;
            var $subway = $('#subway');
            var $city = $('#citypage');
            var $srh = $('#srhpage');


            /** gesture start ***/
            var ticking = false;

            var reqAnimationFrame = (function () {
                return window[Hammer.prefixed(window, 'requestAnimationFrame')] || function (callback) {
                    window.setTimeout(callback, 1000 / 60);
                };
            })();

            function requestElementUpdate() {
                if(!ticking) {
                    reqAnimationFrame(update);
                    ticking = true;
                }
            }

            // pan : 1, pinch : 2
            var getstureState = 0;
            var el = document.getElementById('subway-svg');
            el.style.transformOrigin = "top left";
            var $el = $(el);

            var mgr = new Hammer(el,{
                domEvents: true
            });
            mgr.get('pan').set({ direction: Hammer.DIRECTION_ALL, pointers : 1 });
            mgr.get('pinch').set({ enable: true });


            var state = {
                x : 0,
                y : 0,
                scale : 1
            }

            var transform = {
                x : 0,
                y : 0,
                scale : 1
            }

            var lastAction;
            var enableGesture = true;


            function update() {

                var value = [
                    'translate3d(' + transform.x + 'px, ' + transform.y + 'px, 0)',
                    'scale(' + transform.scale + ')'
                ].join(" ");

                el.style.webkitTransform = value;
                el.style.mozTransform = value;
                el.style.transform = value;

                ticking = false;

            }

            /********************************* PAN *********************************/
            var panTimer;
            mgr.on("pan", function (ev) {

                if( !enableGesture ) return;
                if( getstureState == 2 ) return;
                getstureState = 1;
                panTimer && clearTimeout(panTimer);
                panTimer = setTimeout(function(){
                    getstureState = 0;
                }, 50);

                // console.log("@pan");

                transform.x = state.x + ev.deltaX;
                transform.y = state.y + ev.deltaY;

                if(ev.isFinal) {
                    // console.log("@panend", ev.deltaX, ev.deltaY);
                    state.x = transform.x;
                    state.y = transform.y;
                    lastAction = "panend";
                }

                lastAction = "pan";

                requestElementUpdate();

            });


            /********************************* PINCH *********************************/
            var pinchTimer;
            var prevOffset;

            mgr.on("pinchstart", function(ev){
                state.scale = state.scale || 1;
                prevOffset = $el.offset();
            });


            mgr.on("pinch", function(ev){

                if( transform.scale >= 2 && ev.scale > 1) {}
                if( transform.scale <= 0.3 && ev.scale < 1) {};

                if( !enableGesture ) return;

                getstureState = 2;
                pinchTimer && clearTimeout(pinchTimer);
                pinchTimer = setTimeout(function(){
                    getstureState = 0;
                }, 100);

                transform.scale = state.scale * ev.scale;
                prevScale = transform.scale;

                // console.log("@pinch", transform.scale);

                var perx = (ev.center.x - prevOffset.left) / prevOffset.width;
                var pery = (ev.center.y - prevOffset.top) / prevOffset.height;

                var dx = prevOffset.width * (ev.scale - 1) * perx;
                var dy = prevOffset.height * (ev.scale - 1) * pery;

                transform.x = state.x - dx;
                transform.y = state.y - dy;

                lastAction = "pinch";

                requestElementUpdate();



            });

            mgr.on("hammer.input", function(ev){

                if(ev.isFinal && lastAction == "pinch") {

                    state.scale = prevScale;
                    state.x = transform.x;
                    state.y = transform.y;

                    enableGesture = false;
                    setTimeout(function(){
                        enableGesture = true;
                        // console.log("enableGesture", enableGesture);
                    }, 50);

                }

            });

            requestElementUpdate();

            /** gesture end ***/

            // 城市选择页防止头部滚动
            var mcCityList = new Hammer($('.citylist_wrap').get(0), {
              touchAction: 'pan-y'
            })

            mcCityList.get('pan').set({direction: Hammer.DIRECTION_VERTICAL})
            mcCityList.get('pan').set({enable: true})
            mcCityList.on('pandown', function(event) {
              if (window.scrollY === 0) {
                event.preventDefault()
              }
            })

            $('.light_box').on('touchmove', function(ev) {
                ev.preventDefault();
            });

            $('#loading').on('touchmove', function(ev) {
                ev.preventDefault();
            });

            $subway.on('touchend', 'g', function() {
                if (!self.touchStatus) {
                    if ($(this).hasClass('line_name')) {
                        var line_id = $(this).attr('lineid');
                        self.showFilterLine(line_id);
                    }
                }
            });

            $subway.on('touchend', '#g-bg', function() {
                if (!tip.routeState) {
                    if (!self.touchStatus) {
                        $('#g-select').remove();
                        $('#g-bg').css('display', 'none');
                    }
                }
            });

            $('#subway').on('touchend', function(e) {
                if (drwSw.isNearTip) {
                    drwSw.clearNearTip();
                }
                if (!self.touchStatus) {
                    var target = e.target;
                    if (target.getAttribute('class') != 'station_obj') {
                        tip.closeTip();
                    }
                }
            });

            $(document).on('click', '.station_obj', function(e) {
                e.stopPropagation();
                if (!self.touchStatus) {
                    var obj = $(this);
                    // self.openInfowindow(obj);
                    var center = tip.getStCenter(obj);
                    tip.setCenter(center);
                    tip.openTip(obj);
                }
            });

            $subway.on("click", ".close_info_btn", function(e) {
                self.closeInfoWindow(e);
            });

            $(document).on('click', function(e) {
                self.closeInfoWindow(e);
            });

            $subway.on('click', '.tip_wrap', function(e) {
                e.stopPropagation();
            });

            $subway.on('touchstart', '.tip_wrap', function(e) {
                e.stopPropagation();
            });
            $subway.on('click', '#infowindow-content', function(e) {
                e.stopPropagation();
                // e.preventDefault();
            });

            $subway.on('touchstart', '#infowindow-content', function(e) {
                e.stopPropagation();
                // e.preventDefault();
            });
            $('.filter_btn').on('click', function() {
              if (!tip.routeState) {
                self.openFilter();
              }
            });
            $('.flier_close_btn').on('click', function() {
                self.closeFilter();
            });
            $('.light_box').on('click', function() {
                self.closeFilter();
            });
            $('.fliter_detail').on('click', '.fliter_item', function() {
                var line_id = $(this).attr('lineid');
                self.closeFilter();
                self.showFilterLine(line_id);
                var center = self.getFilterCenter();
                self.setCenter(center);
                self.clearMarker('start');
                self.clearMarker('end');
            });
            $('.fliter_detail').on('touchmove', function(e) {
		          e.stopPropagation();
            });

            // 设为起点
            $('.tip_route_start').on("touchend", function(e) {
              if (!self.touchStatus) {
                var info = $(".tip_route_start").closest('.tip_wrap');
                var type = 'start';
                var id = info.attr('stid');
                tip.setStartEnd(id, type, info);
                tip.closeTip();
                tip.route();
              }
            });

            // 设为终点
            $('.tip_route_end').on("touchend", function(e) {
              if (!self.touchStatus) {
                var info = $(".tip_route_end").closest('.tip_wrap');
                var type = 'end';
                var id = info.attr('stid');
                tip.setStartEnd(id, type, info);
                tip.closeTip();
                tip.route();
              }
            });
            $('.city_list_btn').on('click', function() {
                $('.filter_btn').hide();
                tip.cityChange();
            });

            $city.on('click', '#back_subway', function() {
                // 如果没有地铁图，点击城市列表后退直接退回路线视图
                if (!SW.subwayFlag) {
                  POI.send({
                    "action": "webviewGoBack"
                  });
                } else {
                  $('.filter_btn').show();
                  tip.hideCitylist();
                }
            });

            $city.on('click', '.cityitem', function() {
                var adcode = $(this).attr('adcode');
                tip.initCity();
                SW.changeCity(adcode);
                tip.hideCitylist();
            });
            $(".route_start").on('click', function() {
                var type = 'start';
                tip.showSrhPage(type);
            });

            $(".route_end").on('click', function() {
                var type = 'end';
                tip.showSrhPage(type);
            });

            $("#setSwitch").on("click", function() {
              var start_id = tip.routeId.start,
                  end_id = tip.routeId.end,
                  startInfo = $.extend(true, {}, tip.routeInfo.start),
                  endInfo = $.extend(true, {}, tip.routeInfo.end),
                  typeArr = ['start', 'end'];

              tip.closeRoute(typeArr);
              end_id && tip.setStartEnd(end_id, 'start', endInfo);
              start_id && tip.setStartEnd(start_id, 'end', startInfo);

              if (start_id && end_id) {
                tip.route();
              }
            });
            $('.route_close_start').on("touchend", function() {
                var placeholder = '输入起点';
                var type = 'start';
                $('.route_close_start').addClass('hidden');
                $('.route_start').html(placeholder);
                tip.closeRoute([type]);
            });
            $('.route_close_end').on("touchend", function() {
                var placeholder = '输入终点';
                var type = 'end';
                $('.route_close_end').addClass('hidden');
                $('.route_end').html(placeholder);
                tip.closeRoute([type]);
            });
            $('.route_close_btn').on('click', function(e) {
                e.preventDefault();
                var typeArr = ['start', 'end'];
                tip.closeRoute(typeArr);
            });
            $srh.on('input', '#srh_ipt', function() {
                var value = $(this).val();
                tip.getSug(value);
            });
            $srh.on('click', '#back_ipt', function() {
                var type = $(this).closest('#srhpage').attr('type');
                // tip.clearMarker([type]);
                tip.hideSrhPage();
            });
            $srh.on('click', '.st_item', function() {
                var $this = $(this);
                var id = $this.data('stid'),
                    poiid = $(this).data('poiid'),
                    name = $this.data('name'),
                    lon = $this.data('lon'),
                    lat = $this.data('lat');
                var type = $this.closest('#srhpage').attr('type');
                var info = {
                    'name': name,
                    'poiid': poiid,
                    'lon': lon,
                    'lat': lat
                };
                tip.hideSrhPage();
                tip.setStartEnd(id, type, info);
                tip.closeTip();
                tip.route();
            });
            $('.tip_name_detail').on('touchend', function(e) {
                e.stopPropagation();
                var $obj = $(this).closest('.tip_wrap');
                var poiinfo = {
                    name: $obj.attr('name'),
                    poiid: $obj.attr('poiid'),
                    lon: $obj.attr('lon'),
                    lat: $obj.attr('lat')
                };
                tip.openPoi(poiinfo);
            });
            $('#back_amap').on('click', function() {
                tip.goback()
            });
            $('.route_bar').on('click', function() {
                tip.searchRouteDetail();
            });
        },
        closeInfoWindow: function(e) {
            var self = this;
            // e.stopPropagation;
            $("#infowindow-content").remove();
            if ($("#tip-content").length > 0) {
                $("#tip-content").css("display", "block").addClass("open");
            }
        },
        closeNearTip: function() {
            var self = this;
            var obj = $(".tip-content");
            if (drwSw.isNearTip) {
                if (obj.hasClass('open')) {
                    obj.css("display", "none").removeClass("open");
                }
            }
        },
        openInfowindow: function(obj) {
            var self = this;
            //设置站点的id和名称及关联线路id
            var select_ref_line_id = obj.attr("line_id");
            var select_station_id = obj.attr("station_id");
            var select_station_name = obj.attr("station_name");
            //移除当前打开的infowindow
            $('#infowindow-content').remove();
            //生成infowindow
            var type = self.setInfowindowType(obj);
            self.createInfowindow(type);
            //写首发时间数据
            self.loadinfo(select_ref_line_id, select_station_id);
            //设置infowindow的位置，保证生成infowindow后获取宽高信息
            self.setInfowindowPos(type, obj);
        },
        setInfowindowType: function(object) {
            var left = object.offset().left;
            var top = object.offset().top;
            var type;
            if (left < 160 || (top < 160 && left < 160) || (top < 160 && (left > 160 && left < 1680))) {
                type = 'r'
            } else if (left > 1680 || (top < 160 && left > 1680)) {
                type = 'l'
            } else {
                type = 't'
            }
            return type;
        },
        createInfowindow: function(type) {
            var self = this;
            var subway_box = $('#subway');
            var infowin_content = $('<div class="infowindow-content" id="infowindow-content">');
            var html = '';
            subway_box.append(infowin_content);
            if (type == 't') {
                html = '<div class="info-window-top-out"><div class="info-window"><h3 id="info-title"><span id="station-name"></span><a href="javascript:void(0)" class="close_info_btn">×</a></h3><div id="info-content"><div class="info-detail-content info-content-item info-time"></div></div></div><div class="info-window-bottom ' + SW.tip_bottom + '"><div class="arrow-bg"><i class="arrow"></i></div></div></div>';
            } else if (type == 'r') {
                html = '<div class="info-window-left-out"><div class="info-window-left ' + SW.tip_bottom + '"><div class="arrow-bg"><i class="arrow"></i></div></div><div class="info-window"><h3 id="info-title"><span id="station-name"></span><a href="javascript:void(0)" class="close_info_btn">×</a></h3><div id="info-content"><div class="info-detail-content info-content-item info-time"></div></div></div></div>';
            } else if (type == 'l') {
                html = '<div class="info-window-right-out"><div class="info-window"><h3 id="info-title"><span id="station-name"></span><a href="javascript:void(0)" class="close_info_btn">×</a></h3><div id="info-content"><div class="info-detail-content info-content-item info-time"></div></div></div><div class="info-window-right ' + SW.tip_bottom + '"><div class="arrow-bg"><i class="arrow"></i></div></div></div>';
            }
            infowin_content.append(html);
        },
        setInfowindowPos: function(type, obj) {
            var self = this;
            var info_win = $('.info-window'),
                info_content = $('#infowindow-content');
            var info_win_w = info_win.width(),
                info_win_h = info_win.height();
            var obj_left = obj.offset().left,
                obj_top = obj.offset().top;
            var infowindow_left, infowindow_top;
            if (type == 't') {
                infowindow_left = obj_left + self.station_w / 2;
                infowindow_top = obj_top;
            } else if (type == 'l') {
                infowindow_left = obj_left;
                infowindow_top = obj_top;
            } else if (type == 'r') {
                infowindow_left = obj_left;
                infowindow_top = obj_top;
            }
            info_content.css({
                top: infowindow_top + 'px',
                left: infowindow_left + 'px'
            });
        },
        loadinfo: function(lineId, nodeId) {
            var self = this;
            var select_station_dpt_time = [],
                select_station_name, select_station_ref_line = [],
                infowHtml = [];
            select_station_dpt_time = self.stationsInfo[nodeId].d;
            select_station_name = self.stations[nodeId].n;
            select_station_ref_line = self.stations[nodeId].r.split("|");
            var current_station = {};
            for (var i = 0, len = select_station_dpt_time.length; i < len; i++) {
                var item = select_station_dpt_time[i];
                if (!current_station[item.ls]) {
                    current_station[item.ls] = [];
                }
                current_station[item.ls].push(item);
            }
            $("#info-title #station-name").html(select_station_name);
            var lineid = '';
            for (lineid in current_station) {
                if (current_station.hasOwnProperty(lineid)) {
                    if (self.lines[lineid]) {
                        var line_sub_name = self.lines[lineid].la;
                        if (line_sub_name == '') {

                        } else {
                            line_sub_name = '(' + line_sub_name + ')';
                        }
                        infowHtml.push("<div class=\"time-item\">");
                        infowHtml.push("<h4 class=\"time-item-title\" style=\"border-bottom:1px solid #" + self.lines[lineid].cl + "\"><label class=\"line-label\" style=\"background-color:#" + self.lines[lineid].cl + ";\">地铁" + self.lines[lineid].ln + "</label><label class=\"line-sub-label\">" + line_sub_name + "</label></h4>");
                        infowHtml.push("<ul class=\"time-item-main\">");
                        for (var j = 0; j < 2; j++) {
                            if (current_station[lineid][j]) {
                                var first_time = current_station[lineid][j].ft;
                                var last_time = current_station[lineid][j].lt;
                                // if(^([0-1]\d|2[0-3]):[0-5]\d$)
                                if (first_time.split(':')[0] != '--' && last_time.split(':')[0] != '--') {
                                    infowHtml.push("<li class=\"time-item-detail\">");
                                    infowHtml.push("<div class=\"train-direct fl\"><label class=\"direct-label\">开往</label><span class=\"direct-name\">" + self.stations[current_station[lineid][j].n].n + "</span></div>"); //下一站名，表示方向
                                    infowHtml.push("<div class=\"train-time fl\">");
                                    infowHtml.push("<div class=\"start-time time-box fl\"><label class=\"time-label\">首</label><span class\"time\">" + first_time + "</span></div>"); //首发
                                    infowHtml.push("<div class=\"last-time time-box fl\"><label class=\"time-label\">末</label><span class=\"time\">" + last_time + "</span></div>"); //末发
                                    infowHtml.push("</div>");
                                    infowHtml.push("</li>");
                                }
                            }
                        }
                        infowHtml.push("</ul>");
                        infowHtml.push("</div>");
                    }

                }
            }
            $(".info-time").html(infowHtml.join(""));
        },
        openTip: function(obj) {
            if (obj && !tip.routeState) {
                var self = this;
                self.curopenStation = obj;
                //设置站点的id和名称及关联线路id
                var station_name = obj.attr("station_name"),
                    station_poiid = obj.attr("station_poiid"),
                    station_lon = obj.attr("station_lon"),
                    station_lat = obj.attr("station_lat"),
                    station_id = obj.attr("station_id");

                //移除当前打开的infowindow
                $('#tip_name').html(station_name);
                $('.tip_wrap').attr('stid', station_id)
                    .attr('name', station_name)
                    .attr('poiid', station_poiid)
                    .attr('lon', station_lon)
                    .attr('lat', station_lat);
                $('.tip_wrap_out').show();

                self.setTipPos(obj);
                self.opentip = true;
            }
        },
        setTipPos: function(obj) {
            var self = this;
            var tip_content = $('.tip_wrap_out');
            var obj_left = obj.offset().left,
                obj_top = obj.offset().top;
            var $overlays = $('.overlays');
            var overlaysLeft = parseInt($overlays.css('left')) || 0,
                overlaysTop = parseInt($overlays.css('top')) || 0;

            infowindow_left = obj_left + self.station_w * self.allScale / 2 - overlaysLeft;
            infowindow_top = obj_top + self.station_w * self.allScale / 4 - overlaysTop;

            tip_content.css({
                top: infowindow_top + 'px',
                left: infowindow_left + 'px'
            });
        },
        closeTip: function(status) {
            $('.tip_wrap_out').hide();
            if (!status) {
                tip.opentip = false;
            }
        },
        setCenter: function(center) {
            var self = this;
            var svg_g = $('#svg-g');
            var center_x = center.x,
                center_y = center.y;
            var curTransform = svg_g.attr("transform").match(/(-?\d+(\.\d+)?)/g);
            var translate_x = Number(curTransform[0]),
                translate_y = Number(curTransform[1]),
                scale = curTransform[2];
            var screen_w = document.documentElement.clientWidth,
                screen_h = document.documentElement.clientHeight;

            var moveX = center_x - screen_w / 2,
                moveY = center_y - screen_h / 2;

            translate_x = translate_x - moveX;
            translate_y = translate_y - moveY;

            svg_g.attr("transform", "translate(" + translate_x + "," + translate_y + ") scale(" + scale + ")");

            var $overlays = $('.overlays');
            var oldLeft = parseInt($overlays.css('left')) || 0,
                oldTop = parseInt($overlays.css('top')) || 0;
            var newLeft = Number(oldLeft) - Number(moveX),
                newTop = Number(oldTop) - Number(moveY);
            $overlays.css({
                left: newLeft + 'px',
                top: newTop + 'px'
            });
        },
        openFilter: function() {
            $('.light_box, .filter_content').css('display', 'block');
        },
        closeFilter: function() {
            $('.light_box, .filter_content').css('display', 'none');
        },
        getFilterCenter: function() {
            var self = this;
            var select_g_offset = $('#g-select').offset();
            var select_g_h = document.getElementById("g-select").getBBox().height * self.allScale,
                select_g_w = document.getElementById("g-select").getBBox().width * self.allScale;

            return {
                'x': select_g_offset.left + select_g_w / 2,
                'y': select_g_offset.top + select_g_h / 2
            }
        },
        cityChange: function() {
            tip.creatCitylist();
            tip.showCitylist();
        },
        creatCitylist: function() {
            var city = SW.cityListData;
            if(city){
                var citylist = $('#citylist');
                var cityListHtm = '';
                for (var i = 0; i < city.length; i++) {
                    cityListHtm += '<li class="cityitem" adcode="' + city[i].adcode + '">' + city[i].cityname + '</li>';
                }
                citylist.html(cityListHtm);
            }
        },
        initCity: function () {
            var type = ['start', 'end'];
            tip.closeRoute(type);
        },
        showCitylist: function() {
            $('#citypage').show();
        },
        hideCitylist: function() {
            $('#citypage').hide();
        },
        showSrhPage: function(type) {
            $('.filter_btn').hide();
            var placeholder_txt = '输入起点';
            var $srhpage = $('#srhpage');
            if (type == 'end') {
                placeholder_txt = '输入终点'
            }
            $srhpage.attr('type', type);
            $srhpage.find('#srh_ipt').attr('placeholder', placeholder_txt).val('');
            $srhpage.find('#srhlist').html(' ').addClass('hidden');
            $srhpage.find('.sug_err').addClass('hidden');
            $('#subway').hide();
            $srhpage.show();
            $srhpage.find('#srh_ipt').focus();
        },
        hideSrhPage: function() {
            $('.filter_btn').show();
            var $srhpage = $('#srhpage');
            $srhpage.hide();
            $('#subway').show();
        },
        getStCenter: function (obj) {
            if(obj){
                var st_offset = obj.offset();
                return {
                    'x': st_offset.left,
                    'y': st_offset.top
                }
            }
        },
        getNavCenter: function() {
            var self = this;
            var select_g_offset = $('#g-nav').offset();
            var select_g_h = document.getElementById("g-nav").getBBox().height * self.allScale,
                select_g_w = document.getElementById("g-nav").getBBox().width * self.allScale;

            return {
                'x': select_g_offset.left + select_g_w / 2,
                'y': select_g_offset.top + select_g_h / 2
            }
        },
        showFilterLine: function(id) {
            $('#g-select').remove();
            $('#g-bg').css('display', 'block');
            drwSw.drawSelectLine(SW.cache.lines[id], 'select');
        },
        resetNavData: function(type) {
            tip.routeInfo[type] = null;
            tip.routeId[type] = null;
            tip.navDrwData.linesbar = [];
            tip.navDrwData.lines = {};
            tip.navDrwData.stations = [];
            if(!tip.routeId.start && !tip.routeId.end){
                tip.fromendState = false;
            }
        },
        createNavDrwData: function(param) {
            var self = this;
            var navList = param.buslist[0].segmentlist;
            var navSt = SW.cache.navStations;
            var navLines = SW.cache.navlines;
            var stationName = [];
            for (var i = 0; i < navList.length; i++) {
                var lineid = navList[i].busid;
                var startName = navList[i].startname;
                var endName = navList[i].endname;
                if (navList[i].passdepotname != '') {
                    stationName = navList[i].passdepotname.split(' '); //st
                } else {
                    stationName = [];
                }
                stationName.unshift(startName);
                stationName.push(endName);
                // console.log('stationName',stationName);
                for (var j = 0; j < stationName.length; j++) {

                    self.navDrwData.stations.push(navSt[stationName[j]]);
                }
                var navline = $.extend(true, {}, navLines[lineid]);
                var startname = self.sortStation(stationName, navline);
                var coords = self.setLineCoords(startname, navline);
                navline.c = coords;
                self.navDrwData.lines[navline.ls] = navline;
                tip.navDrwData.linesbar.push(navline);
            }
        },
        sortStation: function(stationName, navline) {
            var self = this;
            var navSt = navline.stname;
            var startIndx = navSt.indexOf(stationName[0]);
            if (navSt[startIndx] != stationName[1]) {
                return stationName.reverse();
            } else {
                return stationName
            }
        },
        setLineCoords: function(st, navline) {
            var navStPxl = [],
                navStRs = [],
                navCoord = null,
                navSt = SW.cache.navStations,
                line_id = navline.ls,
                line_coord = [].concat(navline.c),
                line_loop = navline.lo; //1为环线
            for (var m = 0; m < st.length; m++) {
                var _navst = navSt[st[m]];
                navStPxl.push(_navst.p);
                var _navst_rf = _navst.r.split('|');
                var rf_index = _navst_rf.indexOf(line_id);
                navStRs.push(_navst.rs.split('|')[rf_index]);
            }
            var startNavSt = navStRs[0],
                secondNavSt = navStRs[1],
                endNavSt = navStRs[navStRs.length - 1];
            if (line_loop == '1') {
                var line_coord_tmp = [].concat(line_coord);
                line_coord_tmp.shift();
                line_coord = line_coord.concat(line_coord_tmp);
                aa = line_coord;
                var line_slice = [].concat(line_coord);
                var coordStartIndex = line_coord.indexOf(startNavSt);
                if(navStRs.length == 2){
                    var coordEndIndex = line_coord.indexOf(endNavSt, coordStartIndex);
                    var dis1 = Math.abs(coordEndIndex - coordStartIndex);
                    var coordNextStartIndex = line_coord.indexOf(startNavSt, coordEndIndex);
                    var dis2 = Math.abs(coordNextStartIndex - coordEndIndex);
                    if (dis1 > dis2) {
                        coordStartIndex = coordEndIndex;
                        coordEndIndex = coordNextStartIndex;
                    }
                }else{
                    line_coord = line_coord.slice(coordStartIndex);

                    var coordStartIndex = line_coord.indexOf(startNavSt),
                        coordSecondIndex = line_coord.indexOf(secondNavSt),
                        coordEndIndex = line_coord.indexOf(endNavSt);

                    if (coordSecondIndex > coordEndIndex) {
                        coordStartIndex = coordEndIndex;
                        line_coord = line_coord.slice(coordStartIndex);

                        coordStartIndex = line_coord.indexOf(endNavSt);
                        coordEndIndex = line_coord.indexOf(startNavSt);
                    }
                }

            } else {
                var coordStartIndex = line_coord.indexOf(startNavSt),
                    coordEndIndex = line_coord.indexOf(endNavSt);
            }

            if (coordStartIndex < coordEndIndex) {
                navCoord = line_coord.slice(coordStartIndex, coordEndIndex + 1)
            } else {
                navCoord = line_coord.slice(coordEndIndex, coordStartIndex + 1)
            }

            return navCoord;
        },
        setStartEnd: function(id, type, info) {
            var self = this;
            var name = info.name || info.attr('name');
            var route_info = {
                'name': name,
                'poiid': info.poiid || info.attr('poiid'),
                'lon': info.lon || info.attr('lon'),
                'lat': info.lat || info.attr('lat')
            };

            if (tip.routeId.start == id) {
                tip.routeId.start = null;
                tip.routeInfo.start = null;
                tip.clearMarker('start');
                var placeholder = '输入起点';
                $('.route_start').html(placeholder);
                tip.routeInfo.end = route_info;
                tip.routeId.end = id;
		$('#setStart').find('.route_close').addClass('hidden');
            } else if (tip.routeId.end == id) {
                tip.routeId.end = null;
                tip.routeInfo.end = null;
                tip.clearMarker('end');
                var placeholder = '输入终点';
                $('.route_end').html(placeholder);
                tip.routeInfo.start = route_info;
                tip.routeId.start = id;
		$('#setEnd').find('.route_close').addClass('hidden');
            } else {
                tip.routeInfo[type] = route_info;
                tip.routeId[type] = id;
            }
            tip.setStartEndIpt(name, type);
            tip.setStartEndIcon(id, type);
        },
        setStartEndIpt: function(name, type) {
            var $srh_item = null;
            if (type == 'start') {
                $srh_item = $('#setStart')
            } else if (type == 'end') {
                $srh_item = $('#setEnd')
            }
            $srh_item.find('.route_startend').html(name).removeClass('route_placeholder');
            $srh_item.find('.route_close').removeClass('hidden');
        },
        setStartEndIcon: function(id, type) {
            var self = this;
            var obj = null;
            if ($('#st-' + id).length > 0) {
                obj = $('#st-' + id)
            } else {
                obj = self.curStation;
            }

            var obj_left = obj.offset().left,
                obj_top = obj.offset().top;

            var $overlays = $('.overlays');
            var overlaysLeft = parseInt($overlays.css('left')) || 0,
                overlaysTop = parseInt($overlays.css('top')) || 0;

            var pos = {
                left: obj_left + self.station_w * self.allScale / 2 - overlaysLeft,
                top: obj_top + self.station_w * self.allScale / 2 - overlaysTop
            };

            self.clearMarker(type);
            self.addMarker(type, pos);
        },
        addMarker: function(type, pos) {
            var self = this;
            var marker_wrap = $('#nav_' + type);
            var marker_out = $('<div class="marker-out">');
            var marker = '<img class="nav-img" src="./app/img/subway/' + type + '-marker.png"/>';
            marker_wrap.append(marker_out);
            marker_out.append(marker);
            var marker_top = pos.top;
            var marker_left = pos.left;

            marker_wrap.css({
                top: marker_top + 'px',
                left: marker_left + 'px'
            });

            tip.fromendState = true;
        },
        clearMarker: function(type) {
            var self = this;
            if (type) {
                var marker = $('#nav_' + type).find('.marker-out');
                if (marker.length > 0) {
                    marker.remove();
                }
            }
        },

        updateMarker: function() {
            if (tip.fromendState) {
                var start_id = tip.routeId.start,
                    end_id = tip.routeId.end;
                if (start_id) {
                    tip.updateStartEnd(start_id, 'start')
                }
                if (end_id) {
                    tip.updateStartEnd(end_id, 'end')
                }
            }
        },
        updateStartEnd: function(id, type) {
            var self = this;
            if (id) {
                var obj = null;

                if ($('#st-' + id).length > 0) {
                    obj = $('#st-' + id)
                } else {
                    obj = self.curStation;
                }

                var obj_left = obj.offset().left,
                    obj_top = obj.offset().top;

                var $overlays = $('.overlays');
                var overlaysLeft = parseInt($overlays.css('left')) || 0,
                    overlaysTop = parseInt($overlays.css('top')) || 0;

                var left = obj_left + self.station_w * self.allScale / 2 - overlaysLeft,
                    top = obj_top + self.station_w * self.allScale / 2 - overlaysTop;

                var marker_wrap = $('#nav_' + type);

                marker_wrap.css({
                    top: top + 'px',
                    left: left + 'px'
                });
            }
        },
        updateTip: function() {
            var self = this;
            if (tip.opentip) {
                var obj = tip.curopenStation;

                var obj_left = obj.offset().left,
                    obj_top = obj.offset().top;

                var $overlays = $('.overlays');
                var overlaysLeft = parseInt($overlays.css('left')) || 0,
                    overlaysTop = parseInt($overlays.css('top')) || 0;

                var left = obj_left + self.station_w * self.allScale / 2 - overlaysLeft,
                    top = obj_top + self.station_w * self.allScale / 4 - overlaysTop;

                var tip_wrap = $('.tip_wrap_out');

                tip_wrap.css({
                    top: top + 'px',
                    left: left + 'px'
                });
            }
        },
        updateNear: function() {
            var self = this;
            if (drwSw.nearId) {
                var obj = $('#near-' + drwSw.nearId);

                if (obj) {
                    var obj_left = obj.offset().left,
                        obj_top = obj.offset().top;

                    var $overlays = $('.overlays');
                    var overlaysLeft = parseInt($overlays.css('left')) || 0,
                        overlaysTop = parseInt($overlays.css('top')) || 0;

                    var left = obj_left + 28 * self.allScale / 2 - overlaysLeft,
                        top = obj_top - overlaysTop;

                    var tip_wrap = $('.tip-content');

                    tip_wrap.css({
                        top: top + 'px',
                        left: left + 'px'
                    });
                }
            }
        },
        showRouteTitle: function() {
            var start_name = tip.routeInfo.start.name,
                end_name = tip.routeInfo.end.name;
            $('#start_name_title').html(start_name);
            $('#end_name_title').html(end_name);
            $('.route_title_wrap').css('display', 'inline-block');
            $('.city_name').hide();
        },
        hideRouteTitle: function() {
            $('.route_title_wrap').hide();
            $('.city_name').show();
        },
        showRouteBar: function(data) {
            var bus = data.buslist[0];
            if (bus) {
                var lines = tip.navDrwData.linesbar;
                var line_name_arr = [];
                for (var i = 0; i < lines.length; i++) {
                    line_name_arr.push(lines[i].ln);
                }
                var line_name = line_name_arr.join(' > ');
                var fee = bus.expense + '元',
                    time = tip.formatTime(bus.expensetime),
                    stop_count = tip.navDrwData.stations.length - 1 + '站';
                var line_info = time + ' | ' + stop_count + ' | ' + fee;

                $('.route_line').html(line_name);
                $('.route_info').html(line_info);
                $('.route_bar').show();
            }
        },
        hideRouteBar: function() {
            $('.route_bar').hide();
        },
        formatTime: function(le) {
            if (!le || le == '0') {
                return '';
            }
            le = le / 60;
            if (le <= 60) {
                return parseInt(Math.ceil(le)) + '分钟';
            } else {
                var o = Math.floor(le / 60) + '小时';
                if (le % 60 !== 0) {
                    if (Math.floor(le % 60) === 0) {

                    } else {
                        o += Math.floor(le % 60) + '分钟';
                    }
                }
                return o;
            }
        },
        openPoi: function(poiinfo) {
            if (poiinfo) {
                POI.send({
                    "action": "openPoi",
                    "poiInfo": poiinfo,
                    "status": "1"
                });
            }
        },
        unableFlite: function() {
            $('.filter_btn').css({
                'z-index': '10'
            })
        },
        ableFilte: function() {
            $('.filter_btn').css({
                'z-index': '20'
            })
        },
        route: function() {
            var self = this;
            if (tip.routeInfo && tip.routeInfo.start && tip.routeInfo.end) {
                $('#g-select').remove();
                $('#g-bg').css('display', 'none');
                tip.clearRoute();
                SW.loading();
                var cbk = function(res) {
                    var data = JSON.parse(res.content);
                    SW.loadingOver();
                    if (data.count == '1') {
                        tip.pathData = data;

                        tip.createNavDrwData(data);
                        $('#g-bg').css('display', 'block');
                        $('.route_close_btn').removeClass('hidden');
                        drwSw.drawNavLine(tip.navDrwData);
                        // tip.showRouteTitle();
                        tip.showRouteBar(tip.pathData);
                        var center = self.getNavCenter();
                        tip.setCenter(center);
                        tip.unableFlite();
                        tip.routeState = true;

                    } else {
                      $('.route_close').triggerHandler('touchend')

                      // 取消起终点
                      POI.send({
                        action: 'nativeAlert',
                        title: '',
                        message: '抱歉，未找到路线',
                        cancelbutton: '好',
                        // otherbuttons: ['成功']
                      }, function(res) {
                        // Todo
                        tip.routeState = false;
                      })
                    }
                };
                tip.getRouteData(cbk);
            }
        },
        clearRouteIpt: function(type) {
            var placeholder = {
                'start': '输入起点',
                'end': '输入终点'
            };
            var $obj = null;
            if (type == 'start') {
                $obj = $('#setStart')
            } else if (type == 'end') {
                $obj = $('#setEnd')
            }
            $obj.find('.route_startend').html(placeholder[type]);
            $obj.find('.route_close').addClass('hidden');
        },
        clearRoute: function () {
            $('#g-nav').remove();
            $('#g-bg').css('display', 'none');
            $('.route_close_btn').addClass('hidden');
            tip.navDrwData.linesbar = [];
            tip.navDrwData.lines = {};
            tip.navDrwData.stations = [];
        },
        closeRoute: function(typeArr) {
            $('#g-nav').remove();
            $('#g-bg').css('display', 'none');
            $('.route_close_btn').addClass('hidden');
            $.each(typeArr, function(idx, item) {
                tip.clearMarker(item);
                tip.clearRouteIpt(item);
                tip.resetNavData(item);
            });
            tip.hideRouteTitle();
            tip.hideRouteBar();
            tip.ableFilte();
            tip.routeState = false;
        },
        getRouteData: function(cbk) {
            var start_info = tip.routeInfo.start,
                end_info = tip.routeInfo.end;
            POI.send({
                "action": "aosrequest",
                "urlPrefix": "http://s.amap.com/ws/transfer/auth/navigation/bus-ext/",
                // bus/ext 759之后已不再更新
                // "urlPrefix": "http://s.amap.com/ws/mapapi/navigation/bus/ext/",
                "method": "GET",
                "params": [{
                    "x1": start_info.lon,
                    "sign": 1
                }, {
                    "y1": start_info.lat,
                    "sign": 1
                }, {
                    "x2": end_info.lon,
                    "sign": 1
                }, {
                    "y2": end_info.lat,
                    "sign": 1
                }, {
                    "poiid1": start_info.poiid,
                    "sign": 1
                }, {
                    "poiid2": end_info.poiid,
                    "sign": 1
                }, {
                    "type": "6"
                }, {
                    "Ver": 3
                }],
                "alert": {
                  "fail": "抱歉，服务开了小差，请稍候再试。"
                }
            }, cbk);
        },
        searchRouteDetail: function() {
            POI.send({
                "action": "searchRouteDetail",
                "startPoi": tip.routeInfo.start,
                "endPoi": tip.routeInfo.end,
                "pathData": tip.pathData
            });
        },
        goback: function() {
            if (tip.routeState) {
                var type = ['start', 'end'];
                tip.closeRoute(type);
            } else {
                POI.send({
                    "action": "webviewGoBack"
                });
            }
        },
        getSug: function(sug) {
            var curAdcode = SW.cache.curCity.adcode;
            var sugArr = SW.cache.sug[curAdcode];
            if (sug != '') {
                if (sugArr) {
                    var sug_length = sug.length;
                    var new_sug = [];
                    for (var key in sugArr) {
                        var keys = key.split('|');
                        for (var i = 0; i < keys.length; i++) {
                            var sug_match = keys[i].substr(0, sug_length);
                            if (sug_match == sug) {
                                new_sug.push(sugArr[key])
                            }
                        }
                    }
                    tip.showSug(new_sug, sug);
                }
            } else {
                $('#srhlist').html(' ').addClass('hidden');
            }
        },
        showSug: function(sugarr, sug) {
            var $suglist = $('#srhlist'),
                $sugerr = $('.sug_err');
            if (sugarr.length > 0) {
                var html = [];
                var lines = SW.cache.lines;
                $.each(sugarr, function(idx, item) {
                    var rf = item.r.split('|');
                    var subhtml = '';
                    $.each(rf, function(subidx, subitem) {
                        var curline = lines[subitem];
                        if (curline) {
                            var knstyle = ''
                            if (!/^\d+$/.test(curline.kn)) {
                                var knstyle = 'knlong'
                            }
                            subhtml += '<li class="rfline ' + knstyle + '" style="background:#' + curline.cl + '">' + curline.ln + '</li>'
                        }
                    })
                    var name = item.n;
                    if (name.indexOf(sug) >= 0) {
                        var sugname = '<b class="match">' + sug + '</b>' + name.substring(sug.length, name.length);
                    } else {
                        var sugname = name;
                    }

                    var lon = item.sl.split(',')[0],
                        lat = item.sl.split(',')[1];

                    html.push('<li class="st_item" data-poiid="' + item.poiid + '" data-stid="'+ item.si +'" data-name="' + item.n + '" data-lon="' + lon + '" data-lat="' + lat + '" data-rf="' + item.r + '"><div class="st_item_wrap"><span class="st_name">' + sugname + '</span><ul class="st_rfline">' + subhtml + '</ul><div class="clr"></div></div></li>');
                })
                $sugerr.addClass('hidden');
                $suglist.html(' ').removeClass('hidden').html(html.join(''));
            } else {
                $suglist.html(' ').addClass('hidden');
                $sugerr.removeClass('hidden');
            }
        }
    };

    window.tip = tip;
    return tip;
});
