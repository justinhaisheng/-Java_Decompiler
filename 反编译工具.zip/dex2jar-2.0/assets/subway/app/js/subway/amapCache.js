define("app/js/subway/amapCache", function(require, exports, module) {
	
    var log = function() {
        console.log.apply(console, arguments);
        console.trace();
    }

    var param2json = function (str) {
        var strArr = str.split('&');
        var json = {};
        if(strArr.length > 0){
            for(var i = 0; i < strArr.length; i++){
                var item = strArr[i].split('=');
                var key = item[0];
                var value = item[1];
                json[key]= value; 
            }
            return json
        }else{  
            return false
        }
    }
    
    var param;
	var os = navigator.userAgent;
	
	if(/Android (\d+\.\d+)/.test(os)){
		param = {
			city: amapKvStorageInit.getItem('city'),
			lnglat: amapKvStorageInit.getItem('lnglat'),
			poiid: amapKvStorageInit.getItem('poiid'),
			detail: amapKvStorageInit.getItem('detail')
		}
	}else{
		var hash = window.location.hash.replace(/^\#/, '');
		param = param2json(hash);
	}

    var adcode = param.city && param.city.substr(0, 4) || "1100";

    var DLTip = {
        dom : [$("#dltip"), $("#ndtip")],
        show : function(i){
            this.dom[i].show();
        },
        hide : function(i){
            this.dom[i].hide();
        }
    };

    window.amapCache = window.amapCache || {};

    (function(window, undefined) {
        var enabledLocalstorage = false,
            defaultOption = {},
            cacheFileListName = {},
            cacheDomListName = {},
            cacheFileListObj = {},
            storage;

        // to see if we can use localStorage
        try {
            storage = window.amapKvStorage; //window.localStorage;
            storage.setItem('TEST', 'TEST');
            storage.getItem('TEST');
            storage.removeItem('TEST');
            enabledLocalstorage = true;
        } catch (e) {
            enabledLocalstorage = false;
        }

        var localVersionKey = "subway-data-version";
        var localVersion = JSON.parse(storage.getItem(localVersionKey));

        if (!localVersion) { localVersion = require('./../data/version'); }

        // before first time to lauch subway set time = 0
        var subwayLaunchKey = "subway-launch-time-" + adcode;
        var subwayFirstBoot = !(storage.getItem(subwayLaunchKey) - 0);
        if(subwayFirstBoot){ storage.setItem(subwayLaunchKey, 1); }
        var subwayIsNewKey = "subway-is-new-" + adcode;

        var appFirstBootKey = "subway-first-boot";
        var appFirstBoot = storage.getItem(appFirstBootKey);
        if(!appFirstBoot){
            storage.setItem(appFirstBootKey, 1);
            appFirstBoot = true;
        } else {
            appFirstBoot = false;
        }

        // clear localStorage that not fetch to the file list from server
        var _clearLocalStorage = function() {
           
            var keys = null;

			//KVStorage do not support length property, but length method
            if (typeof(storage.getAllKeys) === 'function') {

                keys = storage.getAllKeys() || [];

            } else {
				//the original localStorage
                keys = [];

                for (var i = storage.length - 1; i >= 0; i--) {
                    keys.push(storage.key(i));
                }
            }

            for (var i = keys.length - 1; i >= 0; i--) {
                var key = keys[i];
                //log('key', key);
                var subway_key = key.split("/")[0];
                if (subway_key == 'data') {
                    if (!cacheFileListName[key]) {
                        storage.removeItem(key);
                    }
                }
            }
        };

        // load the newest file list from server
        var _loadNewestVersion = function(callback) {

            //localStartup
            //先从本地storage启动，没有storage时从本地文件启动。            
            callback && callback();

            function _clsStorage(){
                var key;
                for (key in window.amapCache.newestVersion) {
                    if (window.amapCache.newestVersion.hasOwnProperty(key)) {
                        var dom_key = key.split('/')[1].split('_')[0];
                        cacheFileListName[key + '_' + window.amapCache.newestVersion[key]] = true;
                    }
                }
                _clearLocalStorage();
            }

            if(appFirstBoot){ return; }

            //check update
            $.ajax({
                url: defaultOption.versionPath + "?t=" + Date.now() + (~~(Math.random() * 10000000)),
                dataType: "json",
                success: function(data) {

                    //log('-----window.amapCache.newestVersion----',window.amapCache.newestVersion);

                    var city_code = adcode;
                    var city_name = fileNameData[adcode];

                    if(!city_name){
                        return;
                    }
					
                    var infoKey = "data/" + city_code + "_info_" + city_name + ".json";
                    var drwKey = "data/" + city_code + "_drw_" + city_name + ".json";
                    var url_drw = window.dataServerPath + drwKey;
                    var url_info = window.dataServerPath + infoKey;

                    //当前城市条目增量更新
                    window.infoNeedUpdate = (localVersion[infoKey] === data[infoKey]) ? false : true;
                    
                    localVersion[infoKey] = data[infoKey];
                    localVersion[drwKey] = data[drwKey];

                    cacheFileListObj = localVersion;
                    window.amapCache.newestVersion = localVersion;
                    storage.setItem(localVersionKey, JSON.stringify(localVersion));

                    var infoStoreKey = infoKey + "_" + cacheFileListObj[infoKey];
                    var drwStoreKey = drwKey + "_" + cacheFileListObj[drwKey];

                    //log(infoStoreKey, storage.getItem(infoStoreKey) && storage.getItem(infoStoreKey).length);
                    //log(drwStoreKey, storage.getItem(drwStoreKey) && storage.getItem(drwStoreKey).length);


                    console.log("need update:", window.infoNeedUpdate);
                    console.log("localStorage:", !!storage.getItem(infoStoreKey));

                    if(!storage.getItem(drwStoreKey)){
                        _loadDataFromServer(url_drw, function(data){
                            if (Object.prototype.toString.call(data) == '[object String]') {
                                data = JSON.parse(data);
                            }
                            storage.setItem(drwStoreKey, JSON.stringify(data));
                            log(drwStoreKey, "saved!");
                            _clsStorage();
                        });
                    }

                    if(!storage.getItem(infoStoreKey)){

                        _loadDataFromServer(url_info, function(data){
                            if (Object.prototype.toString.call(data) == '[object String]') {
                                data = JSON.parse(data);
                            }
                            storage.setItem(infoStoreKey, JSON.stringify(data));
                            log(infoStoreKey, "saved!");
                            _clsStorage();
                        });
                    }
                        
                    // }

                }
            });

        };

        var _init = function(option) {

            if (enabledLocalstorage) {

                window.amapCache.cacheFileListObj = localVersion;
                cacheFileListObj = localVersion;
                defaultOption.versionPath = option.versionPath || 'data/version.json';
                
                _loadNewestVersion(option.complete);

                //if subwayIsNew is true then tip already new
                var subwayIsNew = storage.getItem(subwayIsNewKey);
                setTimeout(function(){
                    if(subwayIsNew && subwayIsNew == '1'){
                        DLTip.show(1);
                        storage.setItem(subwayIsNewKey, 0);
                        setTimeout(function () {
                            DLTip.hide(1);
                        },2000);
                    }
                }, 500);
                
            } else {
                option.complete();
            }

        };
        window.amapCache.init = _init;

        var cacheVersion = function() {}

        // load data from server or localStorage
        var _loadDataFromServer = function(url, callback, error) {

            //log("_loadDataFromServer START:", url);
            if(url.indexOf("info") >= 0 && !appFirstBoot && window.infoNeedUpdate){ DLTip.show(0); }

            $.ajax({
                url: url + "?t=" + Date.now() + (~~(Math.random() * 10000000)),
                type: 'get',
                method: 'get',
                dataType: 'json',
                success: function(res){

                    //log("_loadDataFromServer END:", url);
                    var flag = (url.indexOf("info") >= 0);

                    if(flag) {

                        //newdata download over set this city subwayIsNew true
                        DLTip.hide(0); 

                        if(window.infoNeedUpdate){
                            setTimeout(function(){    
                                DLTip.hide(0);

                                POI.send({
                                  action: 'nativeAlert',
                                  title: '',
                                  message: '已为您更新至最新版地铁图，刷新查看',
                                  cancelbutton: '取消',
                                  otherbuttons: ['好']
                                }, function(res) {

                                  if (res.result == 1) {
                                    location.replace(location.href)
                                  }

                                  storage.setItem(subwayIsNewKey, 1);
                                }) 
                            }, 350);

                        }

                    }

                    //save
                    callback.apply(null, arguments);

                    
                },

                error: function() {

                    error.apply(null, arguments);

                }
            });

        };

        var _loadData = function(filePath, callback, error) {

            var errcb = function(filePath) {

                var path = "./../" + filePath.replace("json", "js");

                require([path], function(data) {

                    callback && callback(data);

                });

            }

            var remotePath = filePath;
            filePath = filePath.replace(window.dataServerPath, "");

            var fileMD5 = cacheFileListObj[filePath];
            if (enabledLocalstorage) {

                var storageKey = filePath + '_' + cacheFileListObj[filePath];

                var subwayData = storage.getItem(storageKey);

                // log("storageInfo", storageKey, !!subwayData);
                if (subwayData) {

                    if (Object.prototype.toString.call(subwayData) == '[object String]') {
                        //log2("info:" + subwayData);
                        callback && callback(JSON.parse(subwayData));
                    } else {
                        //log2("info:" + JSON.stringify(subwayData));
                        callback && callback(subwayData);
                    }

                } else {

                    //storage没了，用本地文件顶上去
                    errcb(filePath);

                    // if(subwayFirstBoot){

                    //     _loadDataFromServer(remotePath, function(data) {

                    //         log("Fetch Data & Save:", storageKey);

                    //         console.log(local);

                    //         if (Object.prototype.toString.call(data) == '[object String]') {
                    //             data = JSON.parse(data);
                    //         }

                    //         storage.setItem(storageKey, JSON.stringify(data));
                    //         // callback(data);
                    //     }, function(xhr, txt, err) {
                    //         //errcb(filePath);
                    //     });

                    // }

                }
            } else {

                _loadDataFromServer(remotePath, function(data) {
                    if (Object.prototype.toString.call(data) == '[object String]') {
                        data = JSON.parse(data);
                    }
                    callback && callback(data);
                }, function(xhr, txt, err) {
                    errcb(filePath);
                });
            }
        };
        window.amapCache.loadData = _loadData;
        window.amapCache.cacheFileListObj = cacheFileListObj;
        window.amapCache.enabledLocalstorage = enabledLocalstorage;
    }(window));

});
