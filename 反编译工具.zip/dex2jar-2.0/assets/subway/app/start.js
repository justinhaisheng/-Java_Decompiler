define("app/start", ['app/js/subway/amapCache', 'app/js/subway/common', 'app/js/subway/drw', 'app/js/subway/main'], function(amapCache, SW){

	SW.swInit();

});
