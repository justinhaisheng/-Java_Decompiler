define("FILELIST", {
    "app/js/subway/amapCache": {
        "type": "js",
        "chksum": "498b01b392dcb68581a6037dab748f18",
        "version": 1
    },
    "app/js/subway/common": {
        "type": "js",
        "chksum": "32e25128bb130b188e7dfab3e8fce370",
        "version": 1
    },
    "app/js/subway/drw": {
        "type": "js",
        "chksum": "9f53429c57d080e99b333f732fd6d948",
        "version": 1
    },
    "app/js/subway/main": {
        "type": "js",
        "chksum": "fee79e6689e8573ef95a33b2a9ccffd1",
        "version": 1
    },
    "boot": {
        "type": "js",
        "chksum": "bbfb437525cd29fd0eef1f21c860ae2e",
        "version": 1
    },
    "version": 1
});