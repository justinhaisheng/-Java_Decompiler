//sofa配置文件
define({
	project: "subway2",
	dirs: ["app/js/subway"],
	bootfile: "boot.js",
	FILELISTfile: "FILELIST.js",
	remoteServer: "http://m.amap.com/subway/program/",
	retryInterval: 20000,
	debugMode: 0
});