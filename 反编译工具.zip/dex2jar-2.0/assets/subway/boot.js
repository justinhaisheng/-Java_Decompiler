define("boot", function(){

	require(["app/start"]);
	require(['check']);

});